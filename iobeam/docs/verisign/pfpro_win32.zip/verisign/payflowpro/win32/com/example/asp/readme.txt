PAYFLOW PRO ASP COM CLIENT EXAMPLE
----------------------------------
This directory contains the ASP example for the Payflow Pro COM client.


REQUIREMENTS
------------
* Microsoft Windows NT 4.0/2000
* Microsoft Internet Information Server 4.0/5.0


CONTENTS
--------
ASPCOMExample.asp:	ASP file for interactive example
ASPCOMExample.htm:	HTML file for interactive example
readme.txt:		This file

HOW TO USE
----------
* Copy pfpro.dll to winnt\system32 directory.
* Copy ASPCOMExample.asp and ASPCOMExample.htm to the root webserver directory, ie. c:\inetpub\wwwroot.
* Edit the ASPCOMExample.asp file to have the right values for the PFProCOMControl object using the params.txt file in the root installation directory as a guide.
* Point your web browser to http:\\<server>\ASPCOMExample.htm, enter the requested information, and click the Process button.
* You should receive a response similar to this:

    RESULT=0&PNREF=VXYZ00912465&ERRCODE=00&AUTHCODE=09TEST&AVSADDR=Y&AVSZIP=N&


NOTE
----
* You must set the SYSTEM environment variable PFPRO_CERT_PATH to point to the 
    directory that contains the file f73e89fd.0 in the certs subdirectory and
    reboot the machine.  For instruction see ..\..\..\bin\readme.txt

CONTACT
-------
{!+
     Verisign, Inc. 
     http://www.verisign.com
-!}
See contact.txt for additional contact information

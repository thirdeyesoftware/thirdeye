PAYFLOW PRO VC COM CLIENT EXAMPLE
---------------------------------
This directory contains the Visual C++ example for the Payflow Pro COM client.


REQUIREMENTS
------------
* Microsoft Windows 95/98/NT 4.0
* Microsoft Visual Studio 6.0


CONTENTS
--------
PNCOMClientTest.cpp:    Visual C++ files for example
PNCOMClientTest.dsp:    Visual C++ files for example
PNCOMClientTest.h:	Visual C++ files for example
PNCOMClientTest.rc:	Visual C++ files for example
PNCOMClientTestDlg.cpp:	Visual C++ files for example
PNCOMClientTestDlg.h:	Visual C++ files for example
readme.txt:             This file
resource.h:		Visual C++ files for example
StdAfx.cpp:		Visual C++ files for example
StdAfx.h:		Visual C++ files for example
pfprocom.cpp:		Visual C++ files for example
prprocom.h:		Visual C++ files for example
res/*:			Visual C++ files for example


HOW TO USE
----------
* Copy pfpro.dll to winnt\system32 directory.
* Run PFProCOMSetup.exe to install and register the Payflow Pro client plugin
* Open the PNCOMClientTest.dsp file in Microsoft Visual Studio.
* Build and run the project.
* Enter the requested information using the params.txt file in the root 
  installation directory as a guide.
* Push the Send button
* You should receive a response similar to this:

    RESULT=0&PNREF=VXYZ00912465&ERRCODE=00&AUTHCODE=09TEST&AVSADDR=Y&AVSZIP=N&


NOTE
----
* You must set the SYSTEM environment variable PFPRO_CERT_PATH to point to the 
    directory that contains the file f73e89fd.0 in the certs subdirectory and
    reboot the machine.


CONTACT
-------
{!+
     Verisign, Inc. 
     http://www.verisign.com
-!}
See contact.txt for additional contact information

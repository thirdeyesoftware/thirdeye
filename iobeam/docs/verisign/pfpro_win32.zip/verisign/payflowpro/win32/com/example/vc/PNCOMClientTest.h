// PNCOMClientTest.h : main header file for the PNCOMCLIENTTEST application
//

#if !defined(AFX_PNCOMCLIENTTEST_H__D02D9884_7A6A_11D2_ABE1_00104B247C71__INCLUDED_)
#define AFX_PNCOMCLIENTTEST_H__D02D9884_7A6A_11D2_ABE1_00104B247C71__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPNCOMClientTestApp:
// See PNCOMClientTest.cpp for the implementation of this class
//

class CPNCOMClientTestApp : public CWinApp
{
public:
	CPNCOMClientTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPNCOMClientTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CPNCOMClientTestApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PNCOMCLIENTTEST_H__D02D9884_7A6A_11D2_ABE1_00104B247C71__INCLUDED_)

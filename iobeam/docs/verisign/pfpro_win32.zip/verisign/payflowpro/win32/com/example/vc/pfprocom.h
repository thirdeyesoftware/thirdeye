// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// IPFProCOM wrapper class

class IPFProCOM : public COleDispatchDriver
{
public:
	IPFProCOM() {}		// Calls COleDispatchDriver default constructor
	IPFProCOM(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IPFProCOM(const IPFProCOM& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GetVendorID();
	void SetVendorID(LPCTSTR lpszNewValue);
	CString GetVendorPassword();
	void SetVendorPassword(LPCTSTR lpszNewValue);
	CString GetHostAddress();
	void SetHostAddress(LPCTSTR lpszNewValue);
	CString GetHostPort();
	void SetHostPort(LPCTSTR lpszNewValue);
	void ProcessTransaction();
	CString GetDebugMode();
	void SetDebugMode(LPCTSTR lpszNewValue);
	CString GetTimeOut();
	void SetTimeOut(LPCTSTR lpszNewValue);
	CString GetProxyAddress();
	void SetProxyAddress(LPCTSTR lpszNewValue);
	CString GetProxyPort();
	void SetProxyPort(LPCTSTR lpszNewValue);
	CString GetProxyLogon();
	void SetProxyLogon(LPCTSTR lpszNewValue);
	CString GetProxyPassword();
	void SetProxyPassword(LPCTSTR lpszNewValue);
	CString GetResponse();
	void SetResponse(LPCTSTR lpszNewValue);
	CString GetParmList();
	void SetParmList(LPCTSTR lpszNewValue);
	void AddBinParm(LPCTSTR name, const VARIANT& value);
	void AddParm(LPCTSTR name, LPCTSTR value);
	long GetDelayedCapture();
	void SetDelayedCapture(long nNewValue);
	void PNInit();
	void PNCleanup();
	long CreateContext(LPCTSTR HostAdd, long HostPort, long TimeOut, LPCTSTR ProxyAdd, long ProxyPort, LPCTSTR ProxyLog, LPCTSTR ProxyPass);
	CString SubmitTransaction(long ptrCtx, LPCTSTR ParmList, long ParmLen);
	void DestroyContext(long ptrCtx);
	CString GetPartnerID();
	void SetPartnerID(LPCTSTR lpszNewValue);
	CString GetUserID();
	void SetUserID(LPCTSTR lpszNewValue);
	CString GetPassword();
	void SetPassword(LPCTSTR lpszNewValue);
	long CreateContext2();
	CString SubmitTransaction2(long ptrCtx);
};

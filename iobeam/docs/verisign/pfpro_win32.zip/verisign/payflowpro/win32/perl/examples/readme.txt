----------------------
Installation  

NOTE: Before you can test this system, you must register for an account.
{!+
You may register for an account at:
    http://www.verisign.com/payment (free for testing purposes).
-!}
Also, the Perl Client must have been installed in the system in order 
for the examples to access the PFProAPI module.  See the readme.txt
file in the main perl directory for steps to install the Perl Client.


Perl Client Examples
--------------------
Directories included:
    cgidemo              - web based cgi transaction example
    ptkpos               - Tk GUI based POS transaction example
    cgitest              - cgi test, see readme.txt in cgitest dir


1) To Install & Test ptkpos:
----------------------------

* You must have a windowing system installing and working on your
  machine in order to run this example.

* You must have Perl installed also to run this example.  For NT,
  this may be obtained from ActiveState, see ..\readme.txt, in the
  INSTALLATION section, under NT Platform.

* You must have the Perl Tk module installed to run the GUI for
  this example.  If you do not have this module installed, then:

  For NT, the Perl Tk module may be obtained using the command: 
     ppm install Tk

  For UNIX, the Perl Tk module may be obtained using the commands:
     perl -MCPAN -e shell;
     cpan> install Tk
     
* On Linux, or any Unix machine which requires it, make the file
  ptkpos.pl executable, i.e. chmod +x ptkpos.pl.

* After the above steps have been completed, then to test the
  ptkpos example, run this command from the ptkpos directory:

     perl ptkpos.pl

* When the GUI appears, simply supply all the values for which
  input boxes are presented.  Pull up the File/Configuration...
  menu selection to display the configuration dialog.  Be sure
  to fill in the User: & Pwd: fields of the Vendor ID tab with
  the vendor id and vendor password obtained from your Payflow
  registration, and then click OK to accept.

* Finally, click the Process Transaction button on the main
  window to submit the test transaction.  If you have supplied
  all required values & have connectivity to the Payflow server,
  you should receive a successful response in the Recvd section.


2) To Install & Test cgidemo:
-----------------------------
In addition to the documentation here, please read the assumptions 
and notes documented in the comments of the cgidemo.cgi file.  


UNIX Installation:
-----------------

Testing this script requires that your cgi-bin directory is set up with
cgidemo.cgi and the Perl client has been installed in the system, as
described in the readme.txt file in the main perl directory.

1)Put the libpfpro shared object file into a directory which is in the
  global library path.  On most systems, this is /usr/lib, and requires
  root permissions to do so.  The libpfpro shared object is found in the
  ../../lib directory, named libpfpro.so on most platforms:

    cp ../../lib/libpfpro.so /usr/lib

2)Install the Perl Client into the system as described in ../readme.txt.

3)Copy the cgidemo directory into your htdocs(Apache) directory.

4)You must have the Perl Data::Dumper module installed to run this xample.  
If you do not have this module installed, then:

  For UNIX, the Perl Data::Dumper module may be obtained using the commands:
     perl -MCPAN -e shell
     cpan> install Data::Dumper

5)Edit cgidemo.cgi so it has values appropriate for your environment.
  Specifically, you must change the following values in order for the
  example to succeed:

    Change !#/usr/local/bin/perl to the value which specifies the path
    to where perl is installed on your system (possibly !#/usr/bin/perl).
      (Observe the output of the command: which perl, to see this).

    Change/Set the following values as described to the right of each:
      $htmlDir   - cgidemo html dir (i.e. /usr/local/apache/htdocs/cgidemo/)
      $htmlBase  - URL to cgidemo dir (i.e. http://www.mycompany.com/cgidemo/)
      $USER      - Your user id from Payflow registration.
      $VENDOR    - Your vendor id from Payflow registration.
      $PARTNER   - Your partner id from Payflow registration.
      $PWD       - Your vendor password from Payflow registration.
    Optionally, to save session data in a dbm file, set this value:
      $logDir    - session data directory (i.e. /usr/local/apache/logs/).

6)Put cgidemo.cgi, into your cgi-bin directory, and make sure the file
  has execute permissions.  (If ls -l cgidemo.cgi does not show the
  execute permission bit set, perform the appropriate chmod command to
  add execute permissions: chmod +x cgidemo.cgi or chmod 555).

7)Point your web browser to the cgidemo.cgi file and run the test, ie:
    http://<server_name>/cgi-bin/cgidemo.cgi


NT Installation:
---------------

Testing this script requires that the Perl client has been installed in the
system, as described in the readme.txt file in the main perl directory.  
You must have the latest version of the ActiveState port of perl, available
from www.activestate.com.  As of the writing of this document, that was 
Perl 5.005_03 (build 522). 

1)Put the PFPro.dll file into a directory which is in the global library path,
  such as the c:\winnt\system32 directory.

2)Install ActiveState Perl if not already installed, as described in the
  ..\readme.txt file, in the INSTALLATION section, under NT Platform.

3)Install the Perl Client into the system as described in ..\readme.txt,
  in the Binary or Source Installation under NT Platform.

4)Copy cgidemo directory to the root web directory, i.e. c:\inetpub\wwwroot.

5)Enable execute and script permissions in the cgidemo subdirectory of the 
  root web directory, i.e. c:\inetpub\wwwroot\cgidemo directory.  
  
  Note: For IIS to execute a cgi script, the dll mapping for the file
        extension .cgi must be set up.  Map the cgi file extension (.cgi)
        to the dll (c:\perl\bin\perlis.dll) for execution.  This can be
        verified in the cgidemo directory property ->Configure->App Mapping.

6)Edit cgidemo.cgi so it has values appropriate for your environment.
  Specifically, you must change the following values in order for the
  example to succeed:
  
  (Note the use of double backslash "\\" below for NT filesystem directory paths)

    Change/Set the following values as described to the right of each:
      $htmlDir   - cgidemo html dir (i.e. c:\\inetpub\\wwwroot\\cgidemo\\)
      $htmlBase  - URL to cgidemo dir (i.e. http://www.mycompany.com/cgidemo/)
      $USER      - Your user id from Payflow registration.
      $VENDOR    - Your vendor id from Payflow registration.
      $PARTNER   - Your partner id from Payflow registration.
      $PWD       - Your vendor password from Payflow registration.
    Optionally, to save session data in a dbm file, set this value:
      $logDir    - session data directory (i.e. c:\\inetpub\\wwwroot\\cgidemo\\).

7)Point your web browser to the cgidemo.cgi file and run the test, ie:
    http://<server_name>/cgidemo/cgidemo.cgi


CONTACT
-------
{!+
     Verisign, Inc. 
     http://www.verisign.com
-!}
See contact.txt for additional contact information
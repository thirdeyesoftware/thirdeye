Copyright (c) 1999-2002 Verisign, Inc. All Rights Reserved
{!+
Verisign, Inc. 
http://www.verisign.com
-!}

See contact.txt for additional contact information

{!+
In addition to this readme file, full product documentation is
available. Download the "Payflow Pro Developer's Guide" from the
"Downloads" page of the VeriSign Manager website:
https://manager.verisign.com
-!}
Requirements:
The Payflow Pro Pure Java Client is supported on JDK 1.2 and higher.


Notes:  

- As of Version 3.06, the Payflow Pro SDK is using the Java JSSE
  for SSL connectivity

- Make sure that Verisign.jar is in your CLASSPATH

- For JDK 1.2 and 1.3, make sure that the JSSE jar files
  are in your CLASSPATH:

        JSSE 1.0.2 files jsse.jar, jnet.jar & jcert.jar
        can be downloaded from:

        http://java.sun.com/products/jsse/index-102.html

  If JDK 1.4 is installed, this step is not necessary, as these
  files are included in the JDK.

- To set the CLASSPATH:

        Win32: 
           set CLASSPATH=%CLASSPATH%;Verisign.jar;.
           set CLASSPATH=%CLASSPATH%;jsse.jar;jcert.jar;jnet.jar

        UNIX:
           The instructions below include both the C Shell and Bourne Shell
           environment commands for setting the CLASSPATH:

           C Shell:

           #!/bin/csh
           if ($?CLASSPATH) then
               setenv CLASSPATH ${CLASSPATH}:Verisign.jar:.
           else
               setenv CLASSPATH Verisign.jar:.
           endif
           setenv CLASSPATH ${CLASSPATH}:jsse.jar:jcert.jar:jnet.jar


           Bourne Shell:

           #!/bin/sh
           CLASSPATH=${CLASSPATH:-}:Verisign.jar:.;export CLASSPATH
           CLASSPATH=${CLASSPATH:-}:jsse.jar:jcert.jar:jnet.jar;export CLASSPATH

  For JDK 1.4, leave out CLASSPATH definition of jsse.jar, jcert.jar and jnet.jar

- Modify your java.security file to configure Java to use the JSSE:

	$JAVAHOME/jre/lib/security/java.security

  ("$JAVAHOME" refers to the specific directory where Java 
   resides on your machine. We use $JAVAHOME because this 
   location varies depending on where you installed Java. 
   Be aware that on Windows NT, if you have installed J2SE 
   yourself, you may have TWO JDK installations. The standard 
   installation can be found under: C:\Program Files\JavaSoft\ 
   Ensure that the proper java.security has been updated.)

  You should add the following entries to your java.security file:

	security.provider.1=sun.security.provider.Sun
	security.provider.2=com.sun.net.ssl.internal.ssl.Provider

  (if you already have existing entries, use the next number available)

- Make sure that the Payflow Pro client cert (f73e89fd.0) can be found by the client.
  To accomplish this, the call to SetCertPath() in PFProJava.java may need to be changed to set the 
  directory that contains the file f73e89fd.0.  For more information on this method, see the javadoc
  documentation in javadoc directory.

- For code examples, please see PFProJava.java

- See the javadoc documentation in javadoc.

- To compile the PFProJava example:
		javac PFProJava.java


To run a test transaction using the PFProJava example 
(you may need to change the user, vendor, partner and password to what you signed up with):
        java PFProJava servername 443 "TRXTYPE=S&TENDER=C&PWD=password&USER=user&VENDOR=vendor&PARTNER=partner&ACCT=5105105105105100&EXPDATE=1209&AMT=1.23&ZIP=12345&comment1=Test Java Transactions" 30

Changes:
        PFProAPI is now in the package com.Verisign.payment.  To use the methods, you must use:

                import com.Verisign.payment.PFProAPI;

        Again, please be sure that your classpath has been set appropriately.
        

Error Messages:

1) If you experience the following error message:

RESULT=-31&RESPMSG=The certificate chain did not validate, no local certificate
found, Modify java.security file to add security provider

  * The solution is to be sure the security provider has been added
    to the java.security file as described above.


2) If you experience the following error message:

RESULT=-31&RESPMSG=The certificate chain did not validate, no local certificate
found, JSSE jar files not found in CLASSPATH

  * The solution is to be sure the JSSE jar files have been included
    in your CLASSPATH as described above.


